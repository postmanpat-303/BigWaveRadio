BigWave Radio v0.1.5 (Rust build)
=================================

Internet radio player for Windows 11 using the radio-browser.info station database.

Just unzip anywhere and run BigWaveRadio.exe.
Keep libunwind.dll beside the exe - the app will not start without it.

What's new in v0.1.5:
- Redesigned player controls: large labelled PREV / PLAY-PAUSE / STOP / NEXT cluster,
  centred in the player bar with text captions under each button
- Fixed station card text spilling over the player bar when scrolled

Created by Derek Heasley
If you find this app useful, you can donate to https://paypal.me/derekh100
Thank you. :)

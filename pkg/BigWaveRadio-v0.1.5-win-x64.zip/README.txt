BigWave Radio 0.1
Internet radio player for Windows 11 (radio-browser.info database).

Created by Derek Heasley.
If you find this app useful, you can donate to https://paypal.me/derekh100
Thank you. :)
